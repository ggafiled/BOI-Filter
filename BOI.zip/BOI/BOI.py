import argparse
import pandas as pd
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("-c", "--csv", required=True,
   help="csv file that expact to filter only dhl invoice")
ap.add_argument("-n", "--netbay", required=True,
   help="netbay file contains invoice number that provide program filter csv file")
args = vars(ap.parse_args())

csv = pd.read_csv(args['csv']) 
netbay = pd.read_csv(args['netbay'])
netbay = netbay.iloc[:,2]
print(netbay)
df = csv[csv['Invoice number'].isin(netbay)]

print(df)
